

function addTeamMembers(){
  let appendDiv = document.getElementById("addTeamMemberDiv");
  let textNode=document.createTextNode('ihkjhkjhkjhh');
  appendDiv.appendChild('text')
//   let firstName = document.createElement("input");
  

//   firstName.setAttribute('type', 'text');
//   appendDiv.appendChild(firstName);
//   document.getElementsByTagName("input").placeholder = "Team member first name";
}